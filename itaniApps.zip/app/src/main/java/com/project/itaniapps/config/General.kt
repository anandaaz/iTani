package com.project.itaniapps.config

object General {

    const val PRIVATE_MODE = 0
    const val PREF_NAME = "SharedPreferences"
    const val IS_LOGIN = "is_login"
    const val HANDLER_TIME = 3000

}
