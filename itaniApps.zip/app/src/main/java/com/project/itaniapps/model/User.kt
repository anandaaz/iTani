package com.project.itaniapps.model

data class User(
    var id: Int = -1,
    var username: String = "",
    var email: String = "",
    var address: String = "",
    var number: String = "",
    var password: String = "",
)